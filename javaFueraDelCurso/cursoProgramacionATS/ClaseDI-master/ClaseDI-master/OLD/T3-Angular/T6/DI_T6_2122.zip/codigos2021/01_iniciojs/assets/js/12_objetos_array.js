let ford = new Coche("Ford", "Focus", "1234ABC", 123);
let opel = new Coche("Opel", "Corsa", "2345", 150);

ford.mostrarDatos();
opel.mostrarDatos();
