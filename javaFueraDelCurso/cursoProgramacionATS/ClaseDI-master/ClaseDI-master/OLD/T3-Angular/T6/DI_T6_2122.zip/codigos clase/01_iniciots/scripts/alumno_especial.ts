class AlumnoEspecial extends Alumno{

}

