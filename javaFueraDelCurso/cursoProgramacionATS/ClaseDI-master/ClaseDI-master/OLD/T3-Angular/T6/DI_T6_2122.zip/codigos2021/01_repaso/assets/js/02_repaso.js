console.log("Esta es una llamada desde otro fichero");
