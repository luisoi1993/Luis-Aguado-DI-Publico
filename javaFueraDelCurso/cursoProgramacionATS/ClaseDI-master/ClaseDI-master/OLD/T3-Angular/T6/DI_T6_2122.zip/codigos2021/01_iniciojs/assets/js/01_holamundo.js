console.log("Hola mundo");
// definicion de variables
// nombre = valor
let numeroUno = 5;
let numeroDos = 15;
let palabra = "hola";
let acierto = false;
let definida;
let nula = null;
const numeroConstante = 7;

//console.log(numero);
console.log(typeof palabra);
console.log(typeof acierto);
console.log(typeof definida);
console.log(typeof nula);
console.log(typeof numeroConstante);

/*console.log(
  "El valor del numero uno es " +
    numeroUno +
    " y el valor del numero dos es " +
    numeroDos
);*/

console.log(
  `El valor del numero uno es ${numeroUno} y el valor del numero dos es ${numeroDos} y su suma es ${
    numeroUno + numeroDos
  }`
);

console.log(palabra.toLowerCase());
